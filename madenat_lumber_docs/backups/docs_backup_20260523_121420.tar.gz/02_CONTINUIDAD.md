# MADENAT — Estado de Continuidad Técnica

**Versión documental:** 5.1.1  
**Fecha de actualización:** 2026-05-23  
**Estado:** ACTIVO — Continuidad alineada con la corrección del `@depends` y la validación de Fase 6 manual

---

## 1. Propósito

Este documento es el checkpoint técnico vivo del proyecto.  
Debe permitir retomar el trabajo sin reconstruir el contexto desde cero.

---

## 2. Estado actual resumido

### Infraestructura
- Módulo: `madenat_lumber_core`
- Target: Odoo 18 CE
- Ambiente usual: Docker (`odoo18_app`, `db` / `odoo18_db` según stack)
- Arquitectura: modular parcial

### Estado funcional consolidado
- Gates 0 a 3 definidos documentalmente.
- Suite T01–T14 consolidada en documentación.
- Triple capa operativa como regla de negocio.
- Servicio de persistencia y parser ya desacoplados.

### Estado real actual
La actualización reciente de largo por unidad de ingreso dejó documentación y vistas alineadas hacia:
- `length_input_raw`
- `length_uom`
- `length`

La corrección del `@depends` de `_compute_lengthm` ya fue validada y el módulo actualiza sin error de registry. [file:123]

Adicionalmente, Fase 6 financiera ya no está ausente: quedó implementada una acción manual desde shipment para crear consolidación de facturación, con botón visible solo cuando el shipment está en `delivered`. [file:122]

---

## 3. Hallazgo crítico vigente

### Incidente histórico resuelto
Durante la etapa de ajuste de largo/unidad de ingreso se produjo este error:

```text
ValueError: Wrong @depends on '_compute_lengthm'
Dependency field 'lengthinputraw' not found in model lumber.reception.line
```

Ese incidente ya fue resuelto mediante la corrección de nombres en el `@api.depends` y la validación posterior del upgrade. [file:123]

### Estado actual
- Documentación: alineada a `length_input_raw`.
- Vista: alineada a `length_input_raw`.
- Código Python: coherente con el `@depends` corregido.
- Instalación de módulo: sin error de registry.
- Fase 6 manual shipment → consolidation: implementada y cargando correctamente. [file:123][file:122]

---

## 4. Cambios documentados 2026-05-23

### Cambio A — Wizard de actualización masiva
- Se incorpora vista XML del wizard de actualización masiva.
- `subproduct_id` opera con `quick_create`.
- Debe convivir con restricciones comerciales del flujo.

### Cambio B — Largo con unidad de ingreso
- Campo nuevo: `length_uom`.
- Campo nuevo: `length_input_raw`.
- `length` pasa a consolidarse como valor normalizado en metros.
- Factores documentados:
  - `mm = * 0.001`.
  - `ft = * 0.3048`.
  - `m = * 1.0`.

### Cambio C — T29 a T32
Se reservan documentalmente los siguientes escenarios:
- T29: ft → m.
- T30: mm → m.
- T31: m → m.
- T32: quick-create subproducto.

**Nota:** estos escenarios ya no están bloqueados por el `@depends`; quedan pendientes de ejecución formal en la matriz de pruebas. [file:123]

### Cambio D — Fase 6 manual
Se implementó una acción manual `action_create_consolidation_from_shipment` en `madenat_lumber_billing/data/billing_workflows.xml`. [file:122]

Se validó además:
- botón `💰 Crear Consolidación` en `madenat_lumber_logistics/views/lumber_export_shipment_views.xml`.
- visibilidad condicionada a `state = delivered`.
- upgrade limpio de `madenat_lumber_billing`.
- upgrade limpio de `madenat_lumber_logistics`. [file:122]

---

## 5. Estado de pruebas

### Pruebas documentadas consolidadas
- T01–T14: base estable de negocio.
- T15–T28: saneamiento y blindaje documental ya registrados en matriz histórica.

### Pruebas bloqueadas o no cerradas
- T29–T32 siguen pendientes de ejecución formal.
- Fase 6 requiere validación funcional extremo a extremo en UI. [file:123][file:122]

---

## 6. Prioridades inmediatas

### Prioridad 1 — Cerrar evidencia de largo/unidades
- Confirmar trazabilidad documental de `length_input_raw` y `length_uom`.
- Mantener alineación entre documentación, vista y compute.

### Prioridad 2 — Revalidar upgrade cuando haya cambios
- Limpieza de `__pycache__` dentro del addon.
- Update del módulo en DB de prueba.
- Validación de carga de vistas y registry.

### Prioridad 3 — Ejecutar T29–T32
- Ajustar matriz de tests.
- Registrar resultados formales.
- Cerrar continuidad cuando existan evidencias reproducibles.

### Prioridad 4 — Validar Fase 6 manual
- Abrir shipment en `delivered`.
- Verificar botón `Crear Consolidación`.
- Ejecutar acción.
- Confirmar creación de `lumber.billing.consolidation`.
- Confirmar creación de `lumber.billing.consolidation.line`. [file:122][file:123]

---

## 7. Riesgos activos

| Riesgo | Severidad | Estado |
|---|---|---|
| Constraint `stock_lot_check_cost_positive` | Alta | Abierto |
| Modelo financiero ausente | Alta | Abierto |
| Warnings XML menores | Media | Abierto |
| Monolito parcial en `lumber_reception.py` | Media | Abierto |

---

## 8. Qué tocar y qué no tocar

### Sí tocar
- documentación canónica.
- compute y depends de largo.
- tests de largo.
- continuidad y decisión técnica.
- validación funcional del flujo manual shipment → consolidation.

### No tocar aún
- arquitectura global congelada.
- refactor grande de separación de archivos.
- automatizaciones adicionales de billing antes de cerrar validación funcional.

---

## 9. Punto de retoma recomendado

1. Hacer grep de `lengthinputraw`, `length_input_raw`, `lengthuom`, `length_uom`, `_compute_lengthm`.
2. Confirmar que los nombres documentados coinciden con el código.
3. Ejecutar T29–T32 y registrar evidencia.
4. Validar en UI el flujo manual `shipment -> Crear Consolidación`.
5. Solo entonces cerrar continuidad y actualizar backlog financiero.

---

## 10. Regla de oro de continuidad

Si se modifica:
- naming de campos,
- unidad de largo,
- computes,
- contratos de Gate 2/Gate 3,
- o flujo financiero shipment → consolidation,

este documento debe actualizarse antes del siguiente checkpoint.

---

## 11. Sesión 23-mayo-2026

- Verificado en `lumber_reception.py` que el campo de unidad de largo se llama `lengthuom`.
- Confirmado que el `@api.depends` de `_compute_lengthm` usa los nombres correctos: (`length_input_raw`, `lengthuom`).
- Comprobado que ya no ocurre el `ValueError: Wrong @depends on '_compute_lengthm'`.
- Verificado que `update --stop-after-init` cargó 85 módulos sin errores críticos.
- Confirmado que la Fase 6 manual quedó cargada correctamente en billing y logistics. [file:123][file:122]