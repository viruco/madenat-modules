# MADENAT — Backlog Canónico

**Versión documental:** 6.2.0  
**Fecha de actualización:** 2026-05-23  
**Estado:** ACTIVO — Prioridad inmediata en estabilización documental y validación funcional de Fase 6

---

## Regla de uso

Este backlog solo debe contener trabajo pendiente, prioridades activas y criterios de cierre.  
Si un tema ya quedó fijado como regla, debe vivir en `04_DECISION_LOG.md`.  
Si un tema ya quedó validado como estado, debe vivir en `02_CONTINUIDAD.md`.  
Si un tema ya quedó evidenciado, debe vivir en `03_TESTS.md`.

---

## FASE 0.5 — SANEAMIENTO CRÍTICO

- [x] Eliminación de campos duplicados.
- [x] Consolidación de decoradores.
- [x] Reparación de importaciones.
- [x] Métodos base completados.
- [x] Tabla centralizada de anchos.
- [x] Servicio de recepción desacoplado.
- [x] Validaciones de rango.
- [x] Base T01–T14 consolidada.

---

## FASE 1 — GATES Y BLINDAJE

- [x] Gate 0.
- [x] Gate 1.
- [x] Gate 2.
- [x] Gate 3.
- [x] Snapshot SHA-256.
- [x] Write único en Gate 3.

---

## FASE 2 — MULTIFORMATO Y TRIPLE CAPA

- [x] Dispatcher Standard / Blanks.
- [x] Triple capa.
- [x] Espejo documental.
- [x] Regla de exportación por línea.

---

## FASE 3 — FLUJO DE PACKING

- [x] Ruta documental → staging → bodega.
- [x] Conciliación volumétrica.
- [x] Propagación `package_no`.
- [x] Picking controlado.

---

## FASE 4 — REFACTOR MODULAR

- [x] Parser extraído.
- [x] Workflow extraído.
- [x] Servicio stock extraído.
- [x] Helpers/mixins extraídos.
- [ ] Separación final de `LumberReceptionLine` a archivo propio.

### Criterio de salida
Cerrar este punto solo si el refactor final no rompe instalación, pruebas ni continuidad.

---

## FASE 5 — CALIDAD Y ESTABILIDAD

- [x] Matriz T01–T14 consolidada.
- [x] Saneamiento documental T15–T28.
- [ ] Formalizar tolerancias por tipo de madera.
- [ ] Limpiar warnings XML.
- [ ] Resolver constraint `stock_lot_check_cost_positive`.

### Criterio de salida
No avanzar a consolidaciones mayores mientras la base técnica siga generando riesgos de instalación o validación.

---

## FASE 5.1 — LARGO Y UNIDADES

### Objetivo
Mantener coherencia documental y funcional del feature de ingreso de largo con unidad seleccionable.

### Tareas
- [x] Localizar referencias a `lengthinputraw`.
- [x] Sustituir por `length_input_raw` donde correspondía.
- [x] Revisar referencias a `lengthuom` / `length_uom`.
- [x] Alinear compute `_compute_lengthm`.
- [x] Reinstalar / actualizar módulo sin error de registry.
- [ ] Ejecutar T29 ft→m.
- [ ] Ejecutar T30 mm→m.
- [ ] Ejecutar T31 m→m.
- [ ] Ejecutar T32 quick-create subproducto.
- [ ] Actualizar continuidad y checklist tras validación formal.

### Criterio de cierre
La fase cierra cuando T29–T32 queden evidenciados en `03_TESTS.md` y reflejados en `02_CONTINUIDAD.md`.

---

## FASE 6 — INTEGRACIÓN FINANCIERA

### Objetivo
Conectar `shipment -> consolidation` mediante acción manual y validar el flujo financiero extremo a extremo.

### Estado actual
- [x] Modelo `lumber.billing.consolidation.line` existe.
- [x] Relación con `stock.lot` existe.
- [x] Acción manual `action_create_consolidation_from_shipment` implementada.
- [x] Botón visible en shipment cuando `state = delivered`.
- [x] Upgrade limpio de `madenat_lumber_billing`.
- [x] Upgrade limpio de `madenat_lumber_logistics`.
- [ ] Validación funcional extremo a extremo en UI.
- [ ] Confirmar creación real de consolidación y líneas.
- [ ] Definir cobertura de tests para este flujo.
- [ ] Reporting financiero por guía/shipment.
- [ ] Revisar documentación heredada de `base_automation` y marcarla como legado si aplica.

### Criterio de salida
No cerrar Fase 6 mientras no exista evidencia funcional en UI, cobertura mínima de validación y trazabilidad documental completa.

---

## PRÓXIMAS TAREAS

1. Validar T29–T32 con evidencia.
2. Cerrar continuidad técnica del flujo de largo/unidades.
3. Ejecutar validación UI de Fase 6.
4. Definir tests del flujo financiero.
5. Registrar qué documentación satélite debe pasar a `LEGADO/`.

---

## RIESGOS ACTIVOS

| Riesgo | Severidad | Acción | Estado |
|---|---|---|---|
| Constraint costo positivo | Alta | revisar data/modelo | ABIERTO |
| Fase 6 parcialmente validada | Media | probar flujo real y tests | ABIERTO |
| Monolito parcial | Media | refactor futuro | ABIERTO |
| Tolerancias no formalizadas | Media | parametrizar | ABIERTO |

---

## REGLA DE PRIORIZACIÓN

No abrir un frente mayor nuevo mientras:
- el módulo no instale limpio.
- el feature de largo/unidades siga inconsistente.
- o T29–T32 no estén validados formalmente.