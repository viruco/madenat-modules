# Índice de Documentación — MADENAT Lumber Core

## Núcleo canónico

- `00_ARQUITECTURA.md` — Base técnica, componentes, gates y restricciones.
- `01_FLUJO_PACKING.md` — Flujo funcional de packing y reglas operativas.
- `02_CONTINUIDAD.md` — Checkpoint vivo para retoma operativa.
- `03_TESTS.md` — Matriz de pruebas y evidencia funcional.
- `04_DECISION_LOG.md` — Decisiones técnicas, reglas y criterios permanentes.
- `05_BACKLOG.md` — Priorización ejecutable y fases activas.
- `06_CHECKLIST.md` — Pre-check, validación y cierre de sesión.

## Documentos satélite en transición

- `07_TRABAJO_CON_IA.md` — Política operativa con IA; absorber en decisión log y checklist.
- `ESTADO_MODULO.md` — Snapshot histórico; absorber en continuidad.
- `GUIA_PRODUCCION_FINAL.md` — Guía de cierre; absorber en checklist.
- `HOJA_RUTA_EJECUTIVA.md` — Resumen ejecutivo; absorber en backlog.
- `QUICK_START.md` — Arranque rápido; absorber en checklist o retirar.
- `ROADMAP.md` — Ruta histórica; absorber en backlog.
- `RESUMEN_AUDITORIA_Y_DOCUMENTACION.md` — Síntesis histórica; mover a legado o eliminar.
- `CHECKLIST_FINALIZACION.md` — Historial de cierre; conservar en legado si sigue siendo útil.

## Documentos operativos externos

- `MANIFEST_ENTREGA.md` — Documento de entrega; mantener mientras tenga utilidad externa o contractual.

## Histórico y legado

Todo documento que no aporte una decisión nueva, una evidencia nueva o una validación operativa nueva debe moverse a `LEGADO/` antes de su eliminación definitiva.

## Regla de uso

Si un tema aparece en más de un archivo, la autoridad principal es:
- Arquitectura → `00_ARQUITECTURA.md`
- Flujo de packing → `01_FLUJO_PACKING.md`
- Reglas permanentes → `04_DECISION_LOG.md`
- Estado actual → `02_CONTINUIDAD.md`
- Pruebas → `03_TESTS.md`
- Prioridad → `05_BACKLOG.md`
- Operación de sesión → `06_CHECKLIST.md`

## Regla de mantenimiento

Cualquier cambio de naming, gates, cálculo, flujo financiero o criterios de validación debe actualizarse primero en el archivo canónico correspondiente y luego reflejarse en los satélites que sigan vigentes.